﻿namespace ABS
{
    public interface IID
    {
        int Id { get; set; }
    }
}
