﻿namespace GUI
{
    partial class RolForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrabarBTN = new System.Windows.Forms.Button();
            this.PermisoQuitarBTN = new System.Windows.Forms.Button();
            this.PermisoAgregarBTN = new System.Windows.Forms.Button();
            this.RolQuitarBTN = new System.Windows.Forms.Button();
            this.RolAgregarBTN = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RolesTreeview = new System.Windows.Forms.TreeView();
            this.RolesCombobox = new System.Windows.Forms.ComboBox();
            this.PermisosCombobox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // GrabarBTN
            // 
            this.GrabarBTN.AutoSize = true;
            this.GrabarBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.GrabarBTN.Location = new System.Drawing.Point(361, 230);
            this.GrabarBTN.Margin = new System.Windows.Forms.Padding(2);
            this.GrabarBTN.Name = "GrabarBTN";
            this.GrabarBTN.Size = new System.Drawing.Size(58, 27);
            this.GrabarBTN.TabIndex = 20;
            this.GrabarBTN.Text = "Grabar";
            this.GrabarBTN.UseVisualStyleBackColor = true;
            this.GrabarBTN.Click += new System.EventHandler(this.GrabarBTN_Click);
            // 
            // PermisoQuitarBTN
            // 
            this.PermisoQuitarBTN.AutoSize = true;
            this.PermisoQuitarBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.PermisoQuitarBTN.Location = new System.Drawing.Point(365, 143);
            this.PermisoQuitarBTN.Margin = new System.Windows.Forms.Padding(2);
            this.PermisoQuitarBTN.Name = "PermisoQuitarBTN";
            this.PermisoQuitarBTN.Size = new System.Drawing.Size(54, 27);
            this.PermisoQuitarBTN.TabIndex = 19;
            this.PermisoQuitarBTN.Text = "Quitar";
            this.PermisoQuitarBTN.UseVisualStyleBackColor = true;
            this.PermisoQuitarBTN.Click += new System.EventHandler(this.PermisoQuitarBTN_Click);
            // 
            // PermisoAgregarBTN
            // 
            this.PermisoAgregarBTN.AutoSize = true;
            this.PermisoAgregarBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.PermisoAgregarBTN.Location = new System.Drawing.Point(297, 143);
            this.PermisoAgregarBTN.Margin = new System.Windows.Forms.Padding(2);
            this.PermisoAgregarBTN.Name = "PermisoAgregarBTN";
            this.PermisoAgregarBTN.Size = new System.Drawing.Size(64, 27);
            this.PermisoAgregarBTN.TabIndex = 18;
            this.PermisoAgregarBTN.Text = "Agregar";
            this.PermisoAgregarBTN.UseVisualStyleBackColor = true;
            this.PermisoAgregarBTN.Click += new System.EventHandler(this.PermisoAgregarBTN_Click);
            // 
            // RolQuitarBTN
            // 
            this.RolQuitarBTN.AutoSize = true;
            this.RolQuitarBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.RolQuitarBTN.Location = new System.Drawing.Point(365, 50);
            this.RolQuitarBTN.Margin = new System.Windows.Forms.Padding(2);
            this.RolQuitarBTN.Name = "RolQuitarBTN";
            this.RolQuitarBTN.Size = new System.Drawing.Size(54, 27);
            this.RolQuitarBTN.TabIndex = 17;
            this.RolQuitarBTN.Text = "Quitar";
            this.RolQuitarBTN.UseVisualStyleBackColor = true;
            this.RolQuitarBTN.Click += new System.EventHandler(this.RolQuitarBTN_Click);
            // 
            // RolAgregarBTN
            // 
            this.RolAgregarBTN.AutoSize = true;
            this.RolAgregarBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.RolAgregarBTN.Location = new System.Drawing.Point(297, 50);
            this.RolAgregarBTN.Margin = new System.Windows.Forms.Padding(2);
            this.RolAgregarBTN.Name = "RolAgregarBTN";
            this.RolAgregarBTN.Size = new System.Drawing.Size(64, 27);
            this.RolAgregarBTN.TabIndex = 16;
            this.RolAgregarBTN.Text = "Agregar";
            this.RolAgregarBTN.UseVisualStyleBackColor = true;
            this.RolAgregarBTN.Click += new System.EventHandler(this.RolAgregarBTN_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(212, 119);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Permiso";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(212, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Rol";
            // 
            // RolesTreeview
            // 
            this.RolesTreeview.Location = new System.Drawing.Point(8, 7);
            this.RolesTreeview.Margin = new System.Windows.Forms.Padding(2);
            this.RolesTreeview.Name = "RolesTreeview";
            this.RolesTreeview.Size = new System.Drawing.Size(200, 250);
            this.RolesTreeview.TabIndex = 11;
            this.RolesTreeview.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.RolesTreeview_AfterSelect);
            // 
            // RolesCombobox
            // 
            this.RolesCombobox.FormattingEnabled = true;
            this.RolesCombobox.Items.AddRange(new object[] {
            "Administrador",
            "Cajero",
            "Chofer",
            "Estibador",
            "Gerente de Operaciones",
            "Jefe de Logística",
            "Jefe de Venta",
            "Logístico",
            "Vendedor"});
            this.RolesCombobox.Location = new System.Drawing.Point(269, 23);
            this.RolesCombobox.Margin = new System.Windows.Forms.Padding(2);
            this.RolesCombobox.Name = "RolesCombobox";
            this.RolesCombobox.Size = new System.Drawing.Size(150, 23);
            this.RolesCombobox.TabIndex = 23;
            // 
            // PermisosCombobox
            // 
            this.PermisosCombobox.FormattingEnabled = true;
            this.PermisosCombobox.Items.AddRange(new object[] {
            "About",
            "Administración",
            "Camiones",
            "Captura",
            "Clientes",
            "Dashboard",
            "Despacho",
            "Empleados",
            "Facturación",
            "Facturas",
            "Liquidación",
            "Liquidaciones",
            "Logística",
            "Mudanzas",
            "Órdenes",
            "Permisos",
            "Respaldos",
            "Restauraciones",
            "Roles",
            "Seguridad",
            "Tarifas",
            "Venta"});
            this.PermisosCombobox.Location = new System.Drawing.Point(269, 116);
            this.PermisosCombobox.Margin = new System.Windows.Forms.Padding(2);
            this.PermisosCombobox.Name = "PermisosCombobox";
            this.PermisosCombobox.Size = new System.Drawing.Size(150, 23);
            this.PermisosCombobox.TabIndex = 24;
            // 
            // RolForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 282);
            this.Controls.Add(this.RolesCombobox);
            this.Controls.Add(this.PermisosCombobox);
            this.Controls.Add(this.GrabarBTN);
            this.Controls.Add(this.PermisoQuitarBTN);
            this.Controls.Add(this.PermisoAgregarBTN);
            this.Controls.Add(this.RolQuitarBTN);
            this.Controls.Add(this.RolAgregarBTN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RolesTreeview);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RolForm";
            this.Text = "RolForm";
            this.Load += new System.EventHandler(this.RolForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GrabarBTN;
        private System.Windows.Forms.Button PermisoQuitarBTN;
        private System.Windows.Forms.Button PermisoAgregarBTN;
        private System.Windows.Forms.Button RolQuitarBTN;
        private System.Windows.Forms.Button RolAgregarBTN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView RolesTreeview;
        private System.Windows.Forms.ComboBox RolesCombobox;
        private System.Windows.Forms.ComboBox PermisosCombobox;
    }
}