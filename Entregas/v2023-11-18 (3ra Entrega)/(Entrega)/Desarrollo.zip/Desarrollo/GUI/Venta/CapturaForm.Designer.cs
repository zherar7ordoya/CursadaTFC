﻿namespace GUI
{
    partial class CapturaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MontoTextbox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.KilometrosDistanciaTextbox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ObservacionesTextbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.LugarDescargaTextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LugarCargaTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DireccionDestinoTextbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.DireccionOrigenTextbox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.MueblesDatagridview = new System.Windows.Forms.DataGridView();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.FechaServicioDatetimepicker = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.GrabarButton = new System.Windows.Forms.Button();
            this.CategoriaTextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.IdentificadorTextbox = new System.Windows.Forms.TextBox();
            this.NombreTextbox = new System.Windows.Forms.TextBox();
            this.DireccionClienteTextbox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.ClienteIdTextbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MueblesDatagridview)).BeginInit();
            this.SuspendLayout();
            // 
            // MontoTextbox
            // 
            this.MontoTextbox.Location = new System.Drawing.Point(443, 410);
            this.MontoTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.MontoTextbox.Name = "MontoTextbox";
            this.MontoTextbox.Size = new System.Drawing.Size(88, 24);
            this.MontoTextbox.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(440, 391);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 17);
            this.label12.TabIndex = 168;
            this.label12.Text = "Monto";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // KilometrosDistanciaTextbox
            // 
            this.KilometrosDistanciaTextbox.Location = new System.Drawing.Point(156, 410);
            this.KilometrosDistanciaTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.KilometrosDistanciaTextbox.Name = "KilometrosDistanciaTextbox";
            this.KilometrosDistanciaTextbox.Size = new System.Drawing.Size(88, 24);
            this.KilometrosDistanciaTextbox.TabIndex = 9;
            this.KilometrosDistanciaTextbox.Leave += new System.EventHandler(this.KilometrosDistanciaTextbox_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(153, 391);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 17);
            this.label11.TabIndex = 166;
            this.label11.Text = "Distancia en kilómetros";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ObservacionesTextbox
            // 
            this.ObservacionesTextbox.Location = new System.Drawing.Point(21, 352);
            this.ObservacionesTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.ObservacionesTextbox.Name = "ObservacionesTextbox";
            this.ObservacionesTextbox.Size = new System.Drawing.Size(381, 24);
            this.ObservacionesTextbox.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 333);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 17);
            this.label10.TabIndex = 164;
            this.label10.Text = "Observaciones";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LugarDescargaTextbox
            // 
            this.LugarDescargaTextbox.Location = new System.Drawing.Point(21, 304);
            this.LugarDescargaTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.LugarDescargaTextbox.Name = "LugarDescargaTextbox";
            this.LugarDescargaTextbox.Size = new System.Drawing.Size(381, 24);
            this.LugarDescargaTextbox.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 287);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 17);
            this.label5.TabIndex = 162;
            this.label5.Text = "Descripción del lugar de descarga";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LugarCargaTextbox
            // 
            this.LugarCargaTextbox.Location = new System.Drawing.Point(21, 213);
            this.LugarCargaTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.LugarCargaTextbox.Name = "LugarCargaTextbox";
            this.LugarCargaTextbox.Size = new System.Drawing.Size(381, 24);
            this.LugarCargaTextbox.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 196);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 17);
            this.label4.TabIndex = 160;
            this.label4.Text = "Descripción del lugar de carga";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DireccionDestinoTextbox
            // 
            this.DireccionDestinoTextbox.Location = new System.Drawing.Point(21, 257);
            this.DireccionDestinoTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.DireccionDestinoTextbox.Name = "DireccionDestinoTextbox";
            this.DireccionDestinoTextbox.Size = new System.Drawing.Size(381, 24);
            this.DireccionDestinoTextbox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 239);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 17);
            this.label3.TabIndex = 158;
            this.label3.Text = "Dirección de Destino";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DireccionOrigenTextbox
            // 
            this.DireccionOrigenTextbox.Location = new System.Drawing.Point(21, 168);
            this.DireccionOrigenTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.DireccionOrigenTextbox.Name = "DireccionOrigenTextbox";
            this.DireccionOrigenTextbox.Size = new System.Drawing.Size(381, 24);
            this.DireccionOrigenTextbox.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 151);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 17);
            this.label9.TabIndex = 156;
            this.label9.Text = "Dirección de Origen";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MueblesDatagridview
            // 
            this.MueblesDatagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.MueblesDatagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MueblesDatagridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cantidad,
            this.Descripcion});
            this.MueblesDatagridview.Location = new System.Drawing.Point(443, 29);
            this.MueblesDatagridview.Margin = new System.Windows.Forms.Padding(2);
            this.MueblesDatagridview.MultiSelect = false;
            this.MueblesDatagridview.Name = "MueblesDatagridview";
            this.MueblesDatagridview.RowHeadersWidth = 62;
            this.MueblesDatagridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MueblesDatagridview.Size = new System.Drawing.Size(378, 347);
            this.MueblesDatagridview.TabIndex = 7;
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.Width = 83;
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripción";
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.Width = 98;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(440, 12);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 152;
            this.label2.Text = "Muebles";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FechaServicioDatetimepicker
            // 
            this.FechaServicioDatetimepicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FechaServicioDatetimepicker.Location = new System.Drawing.Point(21, 410);
            this.FechaServicioDatetimepicker.Margin = new System.Windows.Forms.Padding(2);
            this.FechaServicioDatetimepicker.Name = "FechaServicioDatetimepicker";
            this.FechaServicioDatetimepicker.Size = new System.Drawing.Size(110, 24);
            this.FechaServicioDatetimepicker.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 391);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 17);
            this.label7.TabIndex = 150;
            this.label7.Text = "Fecha de mudanza";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GrabarButton
            // 
            this.GrabarButton.AutoSize = true;
            this.GrabarButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.GrabarButton.Location = new System.Drawing.Point(763, 407);
            this.GrabarButton.Name = "GrabarButton";
            this.GrabarButton.Size = new System.Drawing.Size(58, 27);
            this.GrabarButton.TabIndex = 12;
            this.GrabarButton.Text = "Grabar";
            this.GrabarButton.UseVisualStyleBackColor = true;
            this.GrabarButton.Click += new System.EventHandler(this.GrabarButton_Click);
            // 
            // CategoriaTextbox
            // 
            this.CategoriaTextbox.Enabled = false;
            this.CategoriaTextbox.Location = new System.Drawing.Point(314, 410);
            this.CategoriaTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.CategoriaTextbox.Name = "CategoriaTextbox";
            this.CategoriaTextbox.Size = new System.Drawing.Size(88, 24);
            this.CategoriaTextbox.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(311, 391);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 17);
            this.label1.TabIndex = 170;
            this.label1.Text = "Categoria";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IdentificadorTextbox
            // 
            this.IdentificadorTextbox.Location = new System.Drawing.Point(104, 38);
            this.IdentificadorTextbox.Name = "IdentificadorTextbox";
            this.IdentificadorTextbox.Size = new System.Drawing.Size(100, 24);
            this.IdentificadorTextbox.TabIndex = 1;
            this.IdentificadorTextbox.Leave += new System.EventHandler(this.IdentificadorTextbox_Leave);
            // 
            // NombreTextbox
            // 
            this.NombreTextbox.Enabled = false;
            this.NombreTextbox.Location = new System.Drawing.Point(104, 68);
            this.NombreTextbox.Name = "NombreTextbox";
            this.NombreTextbox.Size = new System.Drawing.Size(298, 24);
            this.NombreTextbox.TabIndex = 176;
            // 
            // DireccionClienteTextbox
            // 
            this.DireccionClienteTextbox.Enabled = false;
            this.DireccionClienteTextbox.Location = new System.Drawing.Point(104, 98);
            this.DireccionClienteTextbox.Name = "DireccionClienteTextbox";
            this.DireccionClienteTextbox.Size = new System.Drawing.Size(298, 24);
            this.DireccionClienteTextbox.TabIndex = 175;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 101);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 17);
            this.label17.TabIndex = 174;
            this.label17.Text = "Dirección";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 71);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 17);
            this.label18.TabIndex = 173;
            this.label18.Text = "Nombre";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(18, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(80, 17);
            this.label19.TabIndex = 171;
            this.label19.Text = "Identificador";
            // 
            // ClienteIdTextbox
            // 
            this.ClienteIdTextbox.Enabled = false;
            this.ClienteIdTextbox.Location = new System.Drawing.Point(314, 39);
            this.ClienteIdTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.ClienteIdTextbox.Name = "ClienteIdTextbox";
            this.ClienteIdTextbox.Size = new System.Drawing.Size(88, 24);
            this.ClienteIdTextbox.TabIndex = 178;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(250, 41);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 17);
            this.label6.TabIndex = 177;
            this.label6.Text = "ClienteID";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 179;
            this.label8.Text = "Cliente";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(18, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 17);
            this.label13.TabIndex = 180;
            this.label13.Text = "Mudanza";
            // 
            // CapturaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 453);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.IdentificadorTextbox);
            this.Controls.Add(this.NombreTextbox);
            this.Controls.Add(this.DireccionClienteTextbox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.ClienteIdTextbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CategoriaTextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GrabarButton);
            this.Controls.Add(this.MontoTextbox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.KilometrosDistanciaTextbox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.ObservacionesTextbox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.LugarDescargaTextbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LugarCargaTextbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DireccionDestinoTextbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DireccionOrigenTextbox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.MueblesDatagridview);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FechaServicioDatetimepicker);
            this.Controls.Add(this.label7);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "CapturaForm";
            this.Text = "CapturaForm";
            this.Load += new System.EventHandler(this.CapturaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MueblesDatagridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox MontoTextbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox KilometrosDistanciaTextbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ObservacionesTextbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox LugarDescargaTextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox LugarCargaTextbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox DireccionDestinoTextbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DireccionOrigenTextbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView MueblesDatagridview;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker FechaServicioDatetimepicker;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button GrabarButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.TextBox CategoriaTextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox IdentificadorTextbox;
        private System.Windows.Forms.TextBox NombreTextbox;
        private System.Windows.Forms.TextBox DireccionClienteTextbox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox ClienteIdTextbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
    }
}