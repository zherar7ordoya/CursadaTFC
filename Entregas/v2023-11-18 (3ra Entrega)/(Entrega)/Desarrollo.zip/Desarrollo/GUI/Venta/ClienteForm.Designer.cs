﻿namespace GUI
{
    partial class ClienteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.IdentificadorTextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CategoriaCombobox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NombreTextbox = new System.Windows.Forms.TextBox();
            this.DireccionTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TelefonoTextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.EmailTextbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.GrabarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Identificador (DNI/CUIT)";
            // 
            // IdentificadorTextbox
            // 
            this.IdentificadorTextbox.Location = new System.Drawing.Point(163, 12);
            this.IdentificadorTextbox.Name = "IdentificadorTextbox";
            this.IdentificadorTextbox.Size = new System.Drawing.Size(100, 24);
            this.IdentificadorTextbox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(269, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Categoría";
            // 
            // CategoriaCombobox
            // 
            this.CategoriaCombobox.FormattingEnabled = true;
            this.CategoriaCombobox.Items.AddRange(new object[] {
            "Corporativo",
            "Empresarial",
            "Gubernamental",
            "Particular"});
            this.CategoriaCombobox.Location = new System.Drawing.Point(338, 12);
            this.CategoriaCombobox.Name = "CategoriaCombobox";
            this.CategoriaCombobox.Size = new System.Drawing.Size(121, 23);
            this.CategoriaCombobox.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nombre/Razón Social";
            // 
            // NombreTextbox
            // 
            this.NombreTextbox.Location = new System.Drawing.Point(163, 42);
            this.NombreTextbox.Name = "NombreTextbox";
            this.NombreTextbox.Size = new System.Drawing.Size(296, 24);
            this.NombreTextbox.TabIndex = 3;
            // 
            // DireccionTextbox
            // 
            this.DireccionTextbox.Location = new System.Drawing.Point(163, 72);
            this.DireccionTextbox.Name = "DireccionTextbox";
            this.DireccionTextbox.Size = new System.Drawing.Size(296, 24);
            this.DireccionTextbox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(96, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Dirección";
            // 
            // TelefonoTextbox
            // 
            this.TelefonoTextbox.Location = new System.Drawing.Point(163, 102);
            this.TelefonoTextbox.Name = "TelefonoTextbox";
            this.TelefonoTextbox.Size = new System.Drawing.Size(100, 24);
            this.TelefonoTextbox.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(101, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Teléfono";
            // 
            // EmailTextbox
            // 
            this.EmailTextbox.Location = new System.Drawing.Point(338, 102);
            this.EmailTextbox.Name = "EmailTextbox";
            this.EmailTextbox.Size = new System.Drawing.Size(121, 24);
            this.EmailTextbox.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Email";
            // 
            // GrabarButton
            // 
            this.GrabarButton.AutoSize = true;
            this.GrabarButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.GrabarButton.Location = new System.Drawing.Point(401, 151);
            this.GrabarButton.Name = "GrabarButton";
            this.GrabarButton.Size = new System.Drawing.Size(58, 27);
            this.GrabarButton.TabIndex = 8;
            this.GrabarButton.Text = "Grabar";
            this.GrabarButton.UseVisualStyleBackColor = true;
            this.GrabarButton.Click += new System.EventHandler(this.GrabarButton_Click);
            // 
            // ClienteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 190);
            this.Controls.Add(this.GrabarButton);
            this.Controls.Add(this.EmailTextbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TelefonoTextbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DireccionTextbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NombreTextbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CategoriaCombobox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.IdentificadorTextbox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ClienteForm";
            this.Text = "ClienteForm";
            this.Load += new System.EventHandler(this.ClienteForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox IdentificadorTextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CategoriaCombobox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NombreTextbox;
        private System.Windows.Forms.TextBox DireccionTextbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TelefonoTextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmailTextbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button GrabarButton;
    }
}