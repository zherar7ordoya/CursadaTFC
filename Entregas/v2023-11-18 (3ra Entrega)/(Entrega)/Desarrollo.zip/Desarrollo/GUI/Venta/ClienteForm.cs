﻿using BEL;

using BLL;

using System;
using System.Windows.Forms;

namespace GUI
{
    public partial class ClienteForm : BaseForm
    {
        //||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| INICIO

        public string Identificador { get; private set; }
        readonly Empleado empleado;

        public ClienteForm
            (
            Empleado pEmpleado,
            string pIdentificador
            )
        {
            InitializeComponent();
            empleado = pEmpleado;
            Identificador = pIdentificador;
        }

        private void ClienteForm_Load(object sender, EventArgs e)
        {
            this.Text = $"Cliente - {empleado.NombreApellido}";
            IdentificadorTextbox.Text = Identificador;
        }
        
        private void GrabarButton_Click(object sender, EventArgs e)
        {
            ClienteBLL clienteBLL = new ClienteBLL();
            Cliente cliente = new Cliente
            {
                Categoria = CategoriaCombobox.Text,
                Identificador= IdentificadorTextbox.Text,
                Nombre = NombreTextbox.Text,
                Direccion = DireccionTextbox.Text,
                Telefono = TelefonoTextbox.Text,
                Email = EmailTextbox.Text
            };
            clienteBLL.Agregar(cliente);
            Identificador = cliente.Identificador;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
