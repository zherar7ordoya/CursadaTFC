﻿using BEL;

using BLL;

using PdfSharp.Drawing;
using PdfSharp.Pdf;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace GUI
{
    public partial class FacturacionForm : BaseForm
    {
        //||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| INICIO

        readonly Empleado empleado;
        Orden orden = new Orden();
        readonly OrdenBLL ordenBLL = new OrdenBLL();
        
        readonly ClienteBLL clienteBLL = new ClienteBLL();
        Factura factura = new Factura();
        readonly FacturaBLL facturaBLL = new FacturaBLL();

        public FacturacionForm(Empleado pEmpleado)
        {
            InitializeComponent();
            empleado = pEmpleado;
        }

        private void FacturacionForm_Load(object sender, EventArgs e)
        {
            this.Text = $"Facturación - {empleado.NombreApellido}";
            CargarTreeview();
            OrdenesTreeview.AfterSelect += OrdenesTreeview_AfterSelect;
            ContadoRadiobutton.CheckedChanged += ViaContado;
            TransferenciaRadiobutton.CheckedChanged += ViaTransferencia;
        }


        private void CargarTreeview()
        {
            // Recuperar las órdenes con estado "Solicitado"
            List<Orden> ordenes = ordenBLL.ListarEstadoSolicitado();

            // Configuración del TreeView
            OrdenesTreeview.Nodes.Clear();

            // Llena el TreeView con la lista de mudanzas
            foreach (var orden in ordenes)
            {
                // Almacena el objeto en el Tag, necesario luego en el evento AfterSelect
                var ordenNode = new TreeNode($"Orden {orden.Id}")
                {
                    Tag = orden
                };

                ordenNode.Nodes.Add($"Estado: {orden.Estado}");
                ordenNode.Nodes.Add($"Fecha: {orden.Fecha}");
                ordenNode.Nodes.Add($"Dirección de origen: {orden.DireccionOrigen}");
                ordenNode.Nodes.Add($"Descripción del lugar de carga: {orden.LugarCarga}");
                ordenNode.Nodes.Add($"Dirección de destino: {orden.DireccionDestino}");
                ordenNode.Nodes.Add($"Descripción del lugar de descarga: {orden.LugarDescarga}");

                var mueblesNode = new TreeNode("Muebles");
                foreach (var mueble in orden.Muebles)
                {
                    mueblesNode.Nodes.Add($"Cantidad: {mueble.Cantidad}, Descripción: {mueble.Descripcion}");
                }
                ordenNode.Nodes.Add(mueblesNode);

                ordenNode.Nodes.Add($"Observaciones: {orden.Observaciones}");
                ordenNode.Nodes.Add($"Distancia en kilómetros: {orden.KilometrosDistancia}");
                ordenNode.Nodes.Add($"Monto: {orden.Monto}");

                ordenNode.Nodes.Add($"Cliente ID: {orden.ClienteID}");

                // Agrega el nodo de Mudanza al TreeView
                OrdenesTreeview.Nodes.Add(ordenNode);
            }

        }

        private void OrdenesTreeview_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode node = e.Node;

            if (node != null)
            {
                while (node.Parent != null)
                {
                    node = node.Parent;
                }
            }

            MapearDesdeObjetoOrden(node?.Tag as Orden);
        }


        private void MapearDesdeObjetoOrden(Orden pOrden)
        {
            OrdenIdTextbox.Text = pOrden.Id.ToString();
            OrdenFechaDatetimepicker.Text = pOrden.Fecha.ToString();
            OrdenOrigenTextbox.Text = pOrden.DireccionOrigen;
            OrdenDestinoTextbox.Text = pOrden.DireccionDestino;
            OrdenDistanciaTextbox.Text = pOrden.KilometrosDistancia.ToString();
            OrdenMontoTextbox.Text = pOrden.Monto.ToString();

            MapearDesdeObjetoCliente(pOrden.ClienteID);
        }

        private void MapearDesdeObjetoCliente(int pId)
        {
            Cliente cliente = clienteBLL.BuscarPorId(pId);
            ClienteIdentificadorTextbox.Text = cliente.Identificador;
            ClienteNombreTextbox.Text = cliente.Nombre;
            ClienteDireccionTextbox.Text = cliente.Direccion;

            CompletarDatosFactura();
        }

        private void CompletarDatosFactura()
        {
            string detalle = 
                $"Fecha de mudanza: {OrdenFechaDatetimepicker.Text}\n" +
                $"Dirección de Origen: {OrdenOrigenTextbox.Text}\n" +
                $"Dirección de Destino: {OrdenDestinoTextbox.Text}\n" +
                $"Distancia a cubrir: {OrdenDistanciaTextbox.Text}";
            FacturaDetalleTextbox.Text = detalle;
            FacturaSubtotalTextbox.Text = OrdenMontoTextbox.Text;
            float subtotal = float.Parse(FacturaSubtotalTextbox.Text);
            float impuesto = subtotal * 0.21f;
            float total = subtotal + impuesto;
            FacturaImpuestoTextbox.Text = impuesto.ToString();
            FacturaTotalTextbox.Text = total.ToString();
        }

        private void ViaContado(object sender, EventArgs e)
        {
            if (sender is System.Windows.Forms.RadioButton radio)
            {
                if (radio.Checked)
                {
                    MessageBox.Show("Ingrese el dinero en caja y luego indique que el pago ha sido verificado");
                }
            }
        }

        private void ViaTransferencia(object sender, EventArgs e)
        {
            if (sender is System.Windows.Forms.RadioButton radio)
            {
                if (radio.Checked)
                {
                    VerificacionForm formulario = new VerificacionForm(empleado);
                    DialogResult result = formulario.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        MessageBox.Show("De corresponder, indique que el pago ha sido verificado");
                    }
                }
            }
        }


        private void PagoVerificadoCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (PagoVerificadoCheckbox.Checked)
            {
                GenerarFacturaButton.Enabled = true;
            }
            else
            {
                GenerarFacturaButton.Enabled = false;
            }
        }



        private void GenerarFacturaButton_Click(object sender, EventArgs e)
        {
            GrabarFactura();
            CrearPDF();
            CargarTreeview();
        }


        private void GrabarFactura()
        {
            Factura nueva = new Factura
            {
                Fecha = FacturaFechaDatetimepicker.Value,
                MontoOrden = float.Parse(FacturaSubtotalTextbox.Text),
                Impuesto = float.Parse(FacturaImpuestoTextbox.Text),
                Total = float.Parse(FacturaTotalTextbox.Text),
                OrdenID = int.Parse(OrdenIdTextbox.Text)
            };
            facturaBLL.Agregar(nueva);
            factura = facturaBLL.BuscarPorOrdenId(nueva.OrdenID);
            FacturaIdTextbox.Text = factura.Id.ToString();
            orden = ordenBLL.BuscarPorId(nueva.OrdenID);
            orden.Estado = "Pagado";
            ordenBLL.Modificar(orden);
            MessageBox.Show("Factura grabada");
        }

        private void CrearPDF()
        {
            // Crear un documento PDF
            PdfDocument document = new PdfDocument();

            // Añadir una página
            PdfPage page = document.AddPage();
            XGraphics gfx = XGraphics.FromPdfPage(page);
            XFont font = new XFont("Arial", 12, XFontStyle.Regular);

            // Definir posiciones
            int xLeft = 50;
            int xRight = 400;
            int y = 50;
            int lineHeight = 15;

            // Texto fijo en la parte superior izquierda
            gfx.DrawString("La Mudadora", font, XBrushes.Black, xLeft, y);
            gfx.DrawString("Pachi Gorriti 1310", font, XBrushes.Black, xLeft, y + lineHeight);
            gfx.DrawString("Teléfono 3885843652", font, XBrushes.Black, xLeft, y + 2 * lineHeight);

            // Textos de los TextBoxes en la parte superior derecha
            gfx.DrawString("Factura ID: " + FacturaIdTextbox.Text.PadLeft(5, '0'), font, XBrushes.Black, xRight, y);
            gfx.DrawString("Fecha: " + FacturaFechaDatetimepicker.Text, font, XBrushes.Black, xRight, y + lineHeight);

            // Línea divisoria
            y += 3 * lineHeight;
            gfx.DrawLine(XPens.Black, xLeft, y, xRight + 100, y);

            // Información del cliente a la izquierda
            y += lineHeight;
            gfx.DrawString("Identificador: ", font, XBrushes.Black, xLeft, y);
            gfx.DrawString(ClienteIdentificadorTextbox.Text, font, XBrushes.Black, xLeft + 100, y);
            y += lineHeight;
            gfx.DrawString("Cliente: " + ClienteNombreTextbox.Text, font, XBrushes.Black, xLeft, y);
            y += lineHeight;
            gfx.DrawString("Dirección: " + ClienteDireccionTextbox.Text, font, XBrushes.Black, xLeft, y);

            // Información de la orden a la derecha
            gfx.DrawString("Orden ID: ", font, XBrushes.Black, xRight, y);
            gfx.DrawString(OrdenIdTextbox.Text, font, XBrushes.Black, xRight + 100, y);
            //y += lineHeight;

            // Línea divisoria
            y += 5 * lineHeight;
            gfx.DrawLine(XPens.Black, xLeft, y, xRight + 100, y);

            // Información del detalle de lo facturado
            y += lineHeight;
            gfx.DrawString("Detalle del Servicio:", font, XBrushes.Black, xLeft, y);
            y += lineHeight;
            gfx.DrawString("Fecha del Servicio: " + OrdenFechaDatetimepicker.Text, font, XBrushes.Black, xLeft, y);
            gfx.DrawString("Origen: " + OrdenOrigenTextbox.Text, font, XBrushes.Black, xLeft, y + lineHeight);
            gfx.DrawString("Destino: " + OrdenDestinoTextbox.Text, font, XBrushes.Black, xLeft, y + 2 * lineHeight);
            gfx.DrawString("Distancia: " + OrdenDistanciaTextbox.Text + " km", font, XBrushes.Black, xLeft, y + 3 * lineHeight);
            gfx.DrawString("Monto del Servicio: $" + OrdenMontoTextbox.Text, font, XBrushes.Black, xLeft, y + 4 * lineHeight);

            // Línea divisoria
            y += 5 * lineHeight;
            gfx.DrawLine(XPens.Black, xLeft, y, xRight + 100, y);

            // Información del pie de página
            y += lineHeight;
            gfx.DrawString("Subtotal: $" + FacturaSubtotalTextbox.Text, font, XBrushes.Black, xRight, y);
            gfx.DrawString("Impuestos: $" + FacturaImpuestoTextbox.Text, font, XBrushes.Black, xRight, y + lineHeight);
            gfx.DrawString("Total: $" + FacturaTotalTextbox.Text, font, XBrushes.Black, xRight, y + 2 * lineHeight);

            // Guardar el documento PDF con el nombre "Factura" + número de factura
            string facturaNumber = FacturaIdTextbox.Text.PadLeft(5, '0');
            string pdfFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"Factura{facturaNumber}.pdf");
            document.Save(pdfFilePath);

            // Abrir el PDF generado
            Process.Start(pdfFilePath);
        }

        private void CancelarOrdenButton_Click(object sender, EventArgs e)
        {
            orden = ordenBLL.BuscarPorId(int.Parse(OrdenIdTextbox.Text));
            orden.Estado = "Cancelado";
            ordenBLL.Modificar(orden);
            MessageBox.Show("Orden cancelada");
        }
    }
}
