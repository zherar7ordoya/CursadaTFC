﻿using System;
using System.Drawing;
using System.Windows.Forms;

using BLL;
using BEL;
using SRV;

namespace GUI
{
    public partial class AccesoForm : BaseForm
    {
        readonly EmpleadoBLL empleadoBLL;
        public AccesoForm()
        {
            InitializeComponent();
            empleadoBLL = new EmpleadoBLL();
        }
        private void AccesoFRM_Load(object sender, EventArgs e)
        {
            CentrarControles();
        }

        private void CentrarControles()
        {
            // Calcula el centro del formulario
            int formX = this.Width / 2;
            int formY = this.Height / 2;

            // Calcula las ubicaciones para los controles
            int labelUsuarioX = formX - UsuarioLabel.Width - 40;
            int labelUsuarioY = formY - UsuarioLabel.Height - 60;

            int textboxUsuarioX = formX - 30;
            int textboxUsuarioY = formY - UsuarioTextbox.Height - 60;

            int labelContraseñaX = formX - ContraseñaLabel.Width - 40;
            int labelContraseñaY = formY - 20;

            int textboxContraseñaX = formX - 30;
            int textboxContraseñaY = formY - 25;

            int botonAccederX = formX - (AccederButton.Width / 2);
            int botonAccederY = formY + ContraseñaTextbox.Height + 20;

            // Establece las ubicaciones de los controles
            UsuarioLabel.Location = new Point(labelUsuarioX, labelUsuarioY);
            UsuarioTextbox.Location = new Point(textboxUsuarioX, textboxUsuarioY);
            ContraseñaLabel.Location = new Point(labelContraseñaX, labelContraseñaY);
            ContraseñaTextbox.Location = new Point(textboxContraseñaX, textboxContraseñaY);
            AccederButton.Location = new Point(botonAccederX, botonAccederY);
        }

        //********************************************************************\\

        private void AccederBTN_Click(object sender, EventArgs e)
        {
            string username = UsuarioTextbox.Text;
            string password = ContraseñaTextbox.Text;
            Empleado empleado = empleadoBLL.GetByUsername(username);

            if (empleado == null)
            {
                MessageBox.Show("No se ha encontrado al usuario.");
                return;
            }

            if (empleado.Intento > 2)
            {
                MessageBox.Show("Cuenta bloqueada.\nContacte al administrador.");
                return;
            }
            
            if (empleado.Password == Criptografia.Encriptar(password))
            {
                // Reset sobre el usuario
                empleado.Intento = 0;
                empleadoBLL.Modificar(empleado);

                PrincipalForm principal = new PrincipalForm(empleado);
                //{
                //    Usuario = username,
                //    NombreApellido = empleado.NombreApellido
                //};
                Hide();
                principal.Show();
            }
            else
            {
                empleado.Intento++;
                empleadoBLL.Modificar(empleado);

                MessageBox.Show($"Datos incorrectos.\nIntento #{empleado.Intento}");

                if (empleado.Intento > 2)
                {
                    MessageBox.Show("Demasiados intentos.\nSe ha bloqueado la cuenta.\nContacte al administrador.");
                }
            }
        }
    }
}
