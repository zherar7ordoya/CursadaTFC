﻿using System.Windows.Forms;

namespace GUI
{
    public partial class BaseForm : Form
    {
        public BaseForm()
        {
            InitializeComponent();
        }
    }
}
