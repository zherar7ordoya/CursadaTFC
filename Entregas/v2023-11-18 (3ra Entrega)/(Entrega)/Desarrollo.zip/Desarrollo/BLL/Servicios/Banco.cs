﻿namespace BLL
{
    public static class Banco
    {
        public static bool ConfirmarTransferencia()
        {
            return true;
        }
    }
}
