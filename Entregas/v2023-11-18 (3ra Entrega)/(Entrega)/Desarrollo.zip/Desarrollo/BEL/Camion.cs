﻿using ABS;

namespace BEL
{
    public class Camion : IID
    {
        public int Id { get; set; }
        public string Patente { get; set; }
        public string Marca { get; set; }
    }
}
