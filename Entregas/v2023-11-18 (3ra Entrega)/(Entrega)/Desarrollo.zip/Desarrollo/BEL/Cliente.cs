﻿using ABS;

namespace BEL
{
    public class Cliente : IID
    {
        public int Id { get; set; }
        /// <summary>
        /// Corporativo, Empresarial, Gubernamental, Particular
        /// </summary>
        public string Categoria { get; set; }
        /// <summary>
        /// DNI para particulares. CUIT para empresas.
        /// </summary>
        public string Identificador { get; set; }
        /// <summary>
        /// Nombre y Apellido para particulares. Razón Social para empresas.
        /// </summary>
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }

        // Define el formato para mostrar el cliente.
        public override string ToString()
        {
            return $"Cliente #{Id}\n" +
                   $"Categoría: {Categoria}\n" +
                   $"Identificador: {Identificador}\n" +
                   $"Nombre: {Nombre}\n" +
                   $"Dirección: {Direccion}\n" +
                   $"Teléfono: {Telefono}\n" +
                   $"Email: {Email}";
        }
    }
}
