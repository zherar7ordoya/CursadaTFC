﻿using ABS;

namespace BEL
{
    public class Archivo : IID
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

    }
}
